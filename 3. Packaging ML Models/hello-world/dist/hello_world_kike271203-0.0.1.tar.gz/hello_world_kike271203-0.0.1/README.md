# Project Structure

hello-world >> Folder (Hoolds Python Project)
----hello_world >> Top Level Directory
    ----__init__.py >> Module
    ----main.py >> Module


# Virtual Environment Creation

# go to folder directory >> windows use miniconda
conda create -n envi_name python=3.10
conda activate hellodemo

# Setup Tools >> Allows to create packages
pip install setuptools twine
# Create setup.py file >> On Package Base dir
python setup.py sdist >> creates source distribution of package

